package edu.cuhk.csci3310;
import java.util.Arrays;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private int mPasscode;
    String buttonText = "";
    String passcodeText = "";
    private ImageView mShowImage;
    private TextView mShowPasscode;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mShowPasscode = (TextView) findViewById(R.id.passcodeView);
        mShowImage = (ImageView) findViewById(R.id.hidden_bird);
    }

    public void updatePasscode(View view) {
        Button button = (Button) view;
        //Update the input password in Textview.
        buttonText = button.getText().toString();
        passcodeText = passcodeText.concat(buttonText);
        mShowPasscode.setText(passcodeText);
    }

    public void checkPasscode(View view) {
        Button button = (Button) view;
        char[] singleButtonText = passcodeText.toCharArray();
        int[] singleButtonNumber = new int[5];
        int[] singleLuhnNumber = new int [5];
        int luhnSum = 0;
        int luhnDigit;
        // Case 1: The length of input password is not 5
        if (passcodeText.length() != 5){
            //Toast password incorrect message.
            Context context = getApplicationContext();
            CharSequence text = "Password Incorrect";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
            //reset the password for re-entry
            passcodeText = "";
            mShowPasscode.setText(passcodeText);
        }
        // Case 2: The length of input password is 5, need to check luhn digit.
        else{
        // Process of checking 5-th digit whether equals to luhn digit.
        for(int i = 0; i < (singleButtonText.length-1); i++){
            singleButtonNumber[i] = Character.getNumericValue(singleButtonText[i]);
            if (i%2 == 0){
                singleLuhnNumber[i] = singleButtonNumber[i];
            }
            else{
                singleLuhnNumber[i] = 2 * singleButtonNumber[i];
                if (singleLuhnNumber[i] > 9){
                    singleLuhnNumber[i] = 1 + (singleLuhnNumber[i]%10);
                }
            }
            luhnSum = luhnSum + singleLuhnNumber[i];
        }
        luhnDigit = (10 - (luhnSum%10))%10;
        // The successful case
        if(luhnDigit == Character.getNumericValue(singleButtonText[4])){
            //toast bingo
            Context context = getApplicationContext();
            CharSequence text = "Bingo!";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
            //show the hidden image
            ImageView bird = (ImageView)findViewById(R.id.hidden_bird);
            bird.setVisibility(View.VISIBLE);
            //disable all the buttons
            Button button0 = (Button)findViewById(R.id.button0);
            Button button1 = (Button)findViewById(R.id.button1);
            Button button2 = (Button)findViewById(R.id.button2);
            Button button3 = (Button)findViewById(R.id.button3);
            Button button4 = (Button)findViewById(R.id.button4);
            Button button5 = (Button)findViewById(R.id.button5);
            Button button6 = (Button)findViewById(R.id.button6);
            Button button7 = (Button)findViewById(R.id.button7);
            Button button8 = (Button)findViewById(R.id.button8);
            Button button9 = (Button)findViewById(R.id.button9);
            Button buttonunlock = (Button)findViewById(R.id.buttonunlock);
            button0.setEnabled(false);
            button1.setEnabled(false);
            button2.setEnabled(false);
            button3.setEnabled(false);
            button4.setEnabled(false);
            button5.setEnabled(false);
            button6.setEnabled(false);
            button7.setEnabled(false);
            button8.setEnabled(false);
            button9.setEnabled(false);
            buttonunlock.setEnabled(false);
        }
        // Unsuccessful case
        else{
            //toast password incorrect message
            Context context = getApplicationContext();
            CharSequence text = "Password Incorrect";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
            //reset the password for re-entry
            passcodeText = "";
            mShowPasscode.setText(passcodeText);
        }
        }
    }
}